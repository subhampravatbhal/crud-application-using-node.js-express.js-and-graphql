# EXPRESS WITH GRAPHQL AND MONGODB SAMPLE PROJECT SETUP

For instalation fill env values for database 

1) npm i

2) npm run dev

for create build - npm run build

for run build - npm build-server
