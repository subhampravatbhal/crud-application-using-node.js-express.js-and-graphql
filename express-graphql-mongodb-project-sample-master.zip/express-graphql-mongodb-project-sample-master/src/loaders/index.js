import * as user from './user';
import * as project from './project';

export default { user ,project };

